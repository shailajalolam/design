This is a companion site that can be used to generate application server keys and trigger push messages.

To run companion site locally:

    npm install
    npm run start
